"""Two fixed candidate branches and a fresh verifier Room; no model generation."""
import base64
import gzip
import importlib.util
import json
from pathlib import Path
import shlex
import sys

spec = importlib.util.spec_from_file_location('phases', Path(__file__).with_name('remote.py'))
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)
snapshot = sys.argv[1]
mutation = '''from pathlib import Path
p=Path('cmd/fleet/examples/headless/task/report.py')
s=p.read_text()
old='successful = all(check["outcome"] == "SUCCESS" for check in checks)'
assert old in s
p.write_text(s.replace(old,'successful = any(check["outcome"] == "SUCCESS" for check in checks)'))
'''
good = r.restored_command()
# Keep the frozen patch inline but compressed within matrix's command-size limit.
encoded = base64.b64encode(gzip.compress(r.PATCH.read_bytes(), mtime=0)).decode()
good = good.replace(r.patch_b64() + ' | base64 -d', encoded + ' | base64 -d | gzip -d')
bad = good.replace('status=0\n', 'python3 -c ' + shlex.quote(mutation) + '\nstatus=0\n')
cases = r.LAB / 'candidates.json'
cases.write_text(json.dumps({'schema':'rooms.matrix.v1','cases':[
    {'id':'original','command':good}, {'id':'any-success-mutant','command':bad}]}))
out, record = r.run('candidates-v2', [str(r.BIN),'matrix',snapshot,'--image',str(r.IMAGE),
                                  '--toolstore',str(r.STORE),'--cases',str(cases),
                                  '--max-wall','180s','--out',str(r.LAB/'candidates-v2/out'),'--json'])
original = r.collected(out/'out/original')
mutant = r.collected(out/'out/any-success-mutant')
assert original['result']['exit_code'] == 0 and original['patch_matches_input'], original
assert mutant['result']['exit_code'] != 0, mutant
published = out/'out/original/result.patch'
assert r.digest(published) == r.PATCH_SHA256
r.PATCH = published
# Independently authored behavioral oracle; enumerates mixed status combinations.
verify = '''import itertools, runpy
m=runpy.run_path('cmd/fleet/examples/headless/task/report.py')
n=0
for size in range(5):
    for outcomes in itertools.product(['SUCCESS','FAILURE','SKIPPED','UNKNOWN'],repeat=size):
        checks=[{'name':str(i),'conclusion':v} for i,v in enumerate(outcomes)]
        v={'observed_at':'frozen','pull_requests':[{'number':1,'headRefOid':'a'*40,'statusCheckRollup':checks}]}
        result=m['build_report'](v)['pull_requests'][0]['all_checks_successful']
        expected=None if not outcomes else all(v=='SUCCESS' for v in outcomes)
        assert result is expected,(outcomes,result,expected)
        n+=1
print('INDEPENDENT_STATUS_CASES',n)
'''
command = r.restored_command().replace(r.TESTS, r.TESTS+' && python3 -c '+shlex.quote(verify))
verify_out, verification = r.run('selected-verifier', [str(r.BIN),'restore',snapshot,
    '--image',str(r.IMAGE),'--toolstore',str(r.STORE),'--command',command,
    '--max-wall','180s','--out',str(r.LAB/'selected-verifier/out'),'--json'])
verified = r.collected(verify_out/'out')
assert verification['cli_exit'] == 0 and verified['result']['exit_code'] == 0
assert verified['patch_matches_input']
(r.LAB/'branching-result.json').write_text(json.dumps({
    'interpretation':'Fixed original and seeded mutant; not generated candidate quality or an LLM review.',
    'candidate_matrix_cli_exit':record['cli_exit'], 'selected_patch_sha256':r.digest(published),
    'original_exit':original['result']['exit_code'], 'mutant_exit':mutant['result']['exit_code'],
    'verifier_cli_exit':verification['cli_exit'], 'independent_status_cases':341,
    'candidate_seconds':record['elapsed_seconds'],'verifier_seconds':verification['elapsed_seconds'],
    'final_host':r.host_state()},indent=2))
print('BRANCHING_AND_VERIFIER_COMPLETE')
