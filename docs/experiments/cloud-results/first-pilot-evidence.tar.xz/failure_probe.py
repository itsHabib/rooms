"""A timed-out sibling must not erase the successful sibling's artifact."""
import json
import remote as r
snapshot = json.loads((r.LAB/'base/summary.json').read_text())['snapshot']['result']['directory']
cases = r.LAB/'timeout-cases.json'
cases.write_text(json.dumps({'schema':'rooms.matrix.v1','cases':[
    {'id':'fast','command':'printf "survived\\n" > /workspace/out/receipt.txt'},
    {'id':'timeout','command':'sleep 120'}]}))
out, record = r.run('timeout-sibling', [str(r.BIN),'matrix',snapshot,
    '--image',str(r.IMAGE),'--toolstore',str(r.STORE),'--cases',str(cases),
    '--max-wall','10s','--out',str(r.LAB/'timeout-sibling/out'),'--json'])
receipt = out/'out/fast/receipt.txt'
assert record['cli_exit'] != 0
assert receipt.read_text() == 'survived\n'
result = json.loads((out/'out/fast/result.json').read_text())
assert result['status'] == 'succeeded' and result['exit_code'] == 0
host = r.host_state()
for key in ('firecracker_processes','jailer_mounts','netns','taps','restore_intents'):
    assert not host[key], (key,host[key])
assert json.loads(host['rooms_ls'])['rooms'] == []
(r.LAB/'timeout-result.json').write_text(json.dumps({
    'cli_exit':record['cli_exit'],'elapsed_seconds':record['elapsed_seconds'],
    'successful_sibling_receipt':receipt.read_text(),'host':host},indent=2))
print('TIMEOUT_SIBLING_COMPLETE')
