"""Matched concurrent cold baselines on the same host and frozen inputs."""
import concurrent.futures
import json
import threading
import time
import suite
r = suite.r
rows = []
# Keep the first suite's memory file intact.
def sample():
    suite.sample_memory()
# Baseline timing is around the complete batch, including collection and cleanup.
try:
    for count in [2, 4, 8]:
        for repeat in range(2):
            name = f'cold-batch-{count}-{repeat}'
            started = time.monotonic()
            wall = time.time()
            names = [f'{name}-{i}' for i in range(count)]
            with concurrent.futures.ThreadPoolExecutor(max_workers=count) as pool:
                list(pool.map(r.phase_cold, names))
            elapsed = time.monotonic() - started
            for attempt in names:
                suite.check(attempt)
            row = {'run': name, 'count':count, 'elapsed_seconds':elapsed,
                   'started_unix':wall,'completed_per_minute':60*count/elapsed,
                   'attempts':names,'host_after':r.host_state()}
            rows.append(row)
            print('BATCH',name,elapsed,flush=True)
finally:
    (r.LAB/'cold-batches.json').write_text(json.dumps(rows,indent=2))
    (r.LAB/'cold-batches-final-host.json').write_text(json.dumps(r.host_state(),indent=2))
print('COLD_BATCHES_COMPLETE',flush=True)
