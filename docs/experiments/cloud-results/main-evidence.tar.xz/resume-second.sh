#!/bin/bash
set -euo pipefail
cd "$HOME/src"
source "$HOME/.cargo/env"
exec > >(tee "$HOME/lab/bootstrap-resume.log") 2>&1
git apply "$HOME/density-fixtures.patch"
cargo fmt
cargo test --locked -j24 > "$HOME/lab/rust-tests-v2.log" 2>&1
cargo build --release --locked -j24
sudo bash scripts/build-rootfs-alpine.sh --out "$HOME/rooms/images/agent.ext4" --ssh-key "$HOME/.ssh/id_rooms.pub"
sudo -u "$USER" python3 scripts/build-toolstore.py --preset python --out "$HOME/lab/python"
sha256sum target/release/rooms "$HOME/rooms/images/agent.ext4" "$HOME/rooms/images/vmlinux.bin" "$HOME/lab/python/toolstore.sqfs" > "$HOME/lab/hashes.txt"
sudo mkdir -p /root/.ssh
sudo cp "$HOME/.ssh/id_rooms" /root/.ssh/id_rooms
sudo chmod 600 /root/.ssh/id_rooms
sudo target/release/rooms doctor --image "$HOME/rooms/images/agent.ext4" --json > "$HOME/lab/doctor.json"
touch "$HOME/lab/bootstrap.done"
