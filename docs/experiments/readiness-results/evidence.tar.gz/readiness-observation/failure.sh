echo intentional-failure
exit 7
