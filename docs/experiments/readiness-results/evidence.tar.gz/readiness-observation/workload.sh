set -eu
export PATH=/nix/var/rooms/env/bin:$PATH
python3 -c 'assert sum(range(1000)) == 499500; print("readiness-smoke")'
